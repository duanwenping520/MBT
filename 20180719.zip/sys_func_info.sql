prompt Importing table sys_func_info...
set feedback off
set define off
insert into sys_func_info (FUNC_ID, FUNC_DESC, FUNC_I18N, SUP_FUNC_ID, FUNC_LVL, FUNC_URL, FUNC_PARA, CREATE_TIME, CREATE_USER, UPDATE_TIME, UPDATE_USER, RSV1, RSV2, RSV3, RSV4, RSV5, IS_BTN, IS_EDITABLE, SYSTEM_ID, OPT_TYPE)
values ('FTZ_Upload_PreUpload', 'ģ���ļ��ϴ���ʼ��', null, 'FTZ_Upload', null, '/FtzUpload/preUpload', null, null, null, null, null, null, null, null, null, null, '1', '1', 'FTZMIS', 'M');

prompt Done.
