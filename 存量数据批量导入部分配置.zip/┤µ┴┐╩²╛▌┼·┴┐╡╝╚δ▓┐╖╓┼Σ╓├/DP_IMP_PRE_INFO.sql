prompt Importing table DP_IMP_PRE_INFO...
set feedback off
set define off
insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00524', '00001', 'CCT_T_CONVERT_FINANCEMONEYS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00525', '00001', 'CCT_T_CONVERT_FINANCEPROTOS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00526', '00001', 'CCT_T_CONVERT_FINANCERETURNS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00527', '00001', 'CCT_T_CONVERT_GRPCORPS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00528', '00001', 'CCT_T_CONVERT_IMPAWNCONTRACT', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00529', '00001', 'CCT_T_CONVERT_INVCAPITALS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00530', '00001', 'CCT_T_CONVERT_LACKOFINTERESTS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00531', '00001', 'CCT_T_CONVERT_LAWINFORMATION', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00532', '00001', 'CCT_T_CONVERT_LOANBILLS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00533', '00001', 'CCT_T_CONVERT_LOANCONTRACTS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00534', '00001', 'CCT_T_CONVERT_LOANMONEYS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00535', '00001', 'CCT_T_CONVERT_LOANRETURNS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00536', '00001', 'CCT_T_CONVERT_LOGDICS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00537', '00001', 'CCT_T_CONVERT_LOGINFOS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00538', '00001', 'CCT_T_CONVERT_MESSAGEINFOS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00539', '00001', 'CCT_T_CONVERT_MESSAGESTAT', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00540', '00001', 'CCT_T_CONVERT_NTT_DUMMY_ECARD', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00541', '00001', 'CCT_T_CONVERT_NTT_REPLACE_LOG', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00542', '00001', 'CCT_T_CONVERT_OPENAWARDTRUSTS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00543', '00001', 'CCT_T_CONVERT_OPERATERS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00544', '00001', 'CCT_T_CONVERT_OPTROLES', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00545', '00001', 'CCT_T_CONVERT_ORGMSGS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00546', '00001', 'CCT_T_CONVERT_PBCATCOL', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00547', '00001', 'CCT_T_CONVERT_PBCATEDT', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00548', '00001', 'CCT_T_CONVERT_PBCATFMT', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00549', '00001', 'CCT_T_CONVERT_PBCATTBL', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00550', '00001', 'CCT_T_CONVERT_PBCATVLD', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00551', '00001', 'CCT_T_CONVERT_PLEDGECONTRACTS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00552', '00001', 'CCT_T_CONVERT_PROFITS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00553', '00001', 'CCT_T_CONVERT_RECORDREGS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00554', '00001', 'CCT_T_CONVERT_REGCAPITALS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00555', '00001', 'CCT_T_CONVERT_REPORTFILES', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00556', '00001', 'CCT_T_CONVERT_ROLETYPES', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00557', '00001', 'CCT_T_CONVERT_STOCKS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00558', '00001', 'CCT_T_CONVERT_SUPERMANS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00559', '00001', 'CCT_T_CONVERT_SYSDATAS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00560', '00001', 'CCT_T_CONVERT_SYSLOGINFOS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00561', '00001', 'CCT_T_CONVERT_TABLEREGS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00562', '00001', 'CCT_T_CONVERT_USERS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00563', '00001', 'CCT_T_CONVERT_USER_ROLES', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00564', '00001', 'CCT_T_CONVERT_WTJ', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00565', '00001', 'CCT_T_CONVERT_WTJ1', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00566', '00001', 'CCT_T_CONVERT_WTJ2', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00500', '00001', 'CCT_T_CONVERT_BAOHANS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00501', '00001', 'CCT_T_CONVERT_BANKACCEPTS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00502', '00001', 'CCT_T_CONVERT_BAOLIS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00503', '00001', 'CCT_T_CONVERT_BILLDISCOUNTS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00504', '00001', 'CCT_T_CONVERT_BILLEXPS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00505', '00001', 'CCT_T_CONVERT_BINVCAPITALS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00506', '00001', 'CCT_T_CONVERT_BORROWERS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00507', '00001', 'CCT_T_CONVERT_BSS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00508', '00001', 'CCT_T_CONVERT_CASHS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00509', '00001', 'CCT_T_CONVERT_COLREGS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00510', '00001', 'CCT_T_CONVERT_CREDITBUSINESS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00511', '00001', 'CCT_T_CONVERT_DICTIONARYS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00512', '00001', 'CCT_T_CONVERT_DKMESSAGES', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00513', '00001', 'CCT_T_CONVERT_DKRETURN', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00514', '00001', 'CCT_T_CONVERT_DKRETURNS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00515', '00001', 'CCT_T_CONVERT_ENSURECONTRACTS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00516', '00001', 'CCT_T_CONVERT_ERRREGS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00517', '00001', 'CCT_T_CONVERT_EVENTINFORMATION', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00518', '00001', 'CCT_T_CONVERT_FAMILYMEMBERS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00519', '00001', 'CCT_T_CONVERT_FEEDBACKS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00520', '00001', 'CCT_T_CONVERT_FIELDREGS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00521', '00001', 'CCT_T_CONVERT_FINANCEBUSINESS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00522', '00001', 'CCT_T_CONVERT_FINANCECONTACTS', '0', null, null, null);

insert into DP_IMP_PRE_INFO (TASK_ID, STEP_ID, PRE_CONTENT, PRE_TYPE, RSV1, RSV2, RSV3)
values ('00523', '00001', 'CCT_T_CONVERT_FINANCEEXPS', '0', null, null, null);

prompt Done.
